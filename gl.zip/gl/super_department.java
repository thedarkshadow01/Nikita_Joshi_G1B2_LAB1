/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gl;

/**
 *
 * @author Nikita
 */
public class super_department {
    String departmentName(){
        return "Super Department";
    }
    String getTodaysWork(){
        return "No Work as of now";
    }
    String getWorkDeasline(){
        return "Nil";
    }
    String isTodayAHoliday(){
        return "Today is not a holiday";
    }
}